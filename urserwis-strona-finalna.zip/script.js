document.querySelector('.menu-toggle').addEventListener('click', () => {
  document.querySelector('.nav-list').classList.toggle('active');
});